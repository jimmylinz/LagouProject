def test_b(cmdoption):
    print(f"{cmdoption}")