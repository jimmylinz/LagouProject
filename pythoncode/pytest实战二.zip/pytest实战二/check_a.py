def test_a():
    print("check a testa")

class CheckDemo:
    def checktest(self):
        print("check test")